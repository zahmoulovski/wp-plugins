<div id="wp-chat-widget" class="wp-chat-widget <?php echo esc_attr($position_class); ?>">
    <button id="wp-chat-toggle" class="wp-chat-toggle">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
        </svg>
    </button>
    
    <div id="wp-chat-container" class="wp-chat-container">
        <div class="wp-chat-header">
            <span class="wp-chat-title">Chat Support</span>
            <button id="wp-chat-close" class="wp-chat-close">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>
        <div class="wp-chat-content">
            <!-- Content will be populated by JavaScript -->
        </div>
    </div>
</div>