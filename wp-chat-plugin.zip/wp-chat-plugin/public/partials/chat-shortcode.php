<div class="wp-chat-shortcode" style="width: <?php echo esc_attr($atts['width']); ?>; height: <?php echo esc_attr($atts['height']); ?>;">
    <div class="wp-chat-shortcode-container" style="width: 100%; height: 100%; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
        <?php if ($atts['inline'] === 'true'): ?>
            <div class="wp-chat-content" style="height: 100%;">
                <!-- Content will be populated by JavaScript -->
            </div>
        <?php else: ?>
            <div class="wp-chat-header" style="padding: 15px; display: flex; justify-content: space-between; align-items: center;">
                <span class="wp-chat-title">Chat Support</span>
            </div>
            <div class="wp-chat-content" style="height: calc(100% - 54px);">
                <!-- Content will be populated by JavaScript -->
            </div>
        <?php endif; ?>
    </div>
    
    <script type="text/javascript">
        (function($) {
            $(document).ready(function() {
                // Initialize shortcode chat
                if (typeof wpChatInitShortcode === 'function') {
                    wpChatInitShortcode('<?php echo esc_js($atts['inline']); ?>');
                } else {
                    console.error('WP Chat Plugin: wpChatInitShortcode function not available');
                }
            });
        })(jQuery);
    </script>
</div>