# Overview

This is a Klarrion E-Commerce Progressive Web App (PWA) built with React that integrates with WooCommerce REST API to provide a complete mobile-first shopping experience. The application features a modern, responsive design with dark/light theme support, shopping cart functionality, product search, category browsing, and a complete checkout flow.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript running on Vite for fast development and optimized builds
- **Routing**: Wouter for client-side routing with a simple, declarative approach
- **State Management**: React Context API with useReducer for cart state and theme management
- **UI Components**: shadcn/ui component library with Radix UI primitives for accessibility
- **Styling**: TailwindCSS with CSS variables for theme customization

## Mobile-First Design
- **PWA Features**: Service worker support and mobile-optimized UI
- **Touch Interactions**: Pull-to-refresh functionality and swipeable image galleries
- **Responsive Layout**: Bottom navigation for mobile with header navigation
- **Theme System**: Automatic theme switching with brand-appropriate logos

## Data Management
- **API Integration**: Axios for HTTP requests with React Query for caching and state synchronization
- **Local Storage**: Persistent shopping cart and user preferences stored client-side
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Content Sanitization**: DOMPurify for safely rendering HTML content from WooCommerce

## Backend Integration
- **WooCommerce REST API**: Complete integration for products, categories, orders, and customer data
- **Authentication**: WooCommerce customer authentication system
- **Payment Processing**: Integration with WooCommerce payment gateways
- **Order Management**: Full checkout flow with shipping and billing address handling

## Development Tools
- **Build System**: Vite with TypeScript support and hot module replacement
- **Code Quality**: TypeScript for type safety with strict compiler options
- **Asset Management**: Path aliases for clean import statements

# External Dependencies

## WooCommerce Integration
- **WooCommerce REST API**: Primary data source for products, categories, orders, and customer information
- **Environment Variables**: VITE_WC_CONSUMER_KEY and VITE_WC_CONSUMER_SECRET for API authentication
- **API Endpoints**: Products, categories, customers, orders, shipping methods, and payment gateways

## Database (Prepared for Future Use)
- **Drizzle ORM**: Configured with PostgreSQL schema for potential local data storage
- **Neon Database**: Serverless PostgreSQL integration ready for deployment
- **Schema**: Basic user table structure defined but currently using WooCommerce data

## UI and Styling
- **Google Fonts**: Inter font family for consistent typography
- **Lucide React**: Icon library for consistent iconography
- **Radix UI**: Accessibility-focused component primitives
- **TailwindCSS**: Utility-first CSS framework with custom color system

## Development and Deployment
- **Vite Plugins**: React, runtime error overlay, and Replit-specific development tools
- **Build Process**: ESBuild for server-side code bundling and optimization
- **Static Assets**: Configured for external asset loading from attached_assets directory