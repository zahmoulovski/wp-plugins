import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { wooCommerce } from '@/lib/woocommerce';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import { ArrowLeft } from 'lucide-react';

const checkoutSchema = z.object({
  billing: z.object({
    first_name: z.string().min(1, 'First name is required'),
    last_name: z.string().min(1, 'Last name is required'),
    email: z.string().email('Valid email is required'),
    phone: z.string().min(1, 'Phone is required'),
    address_1: z.string().min(1, 'Address is required'),
    address_2: z.string().optional(),
    city: z.string().min(1, 'City is required'),
    postcode: z.string().min(1, 'ZIP code is required'),
    country: z.string().default('US'),
    state: z.string().min(1, 'State is required'),
  }),
  shipping_method: z.string().min(1, 'Shipping method is required'),
  payment_method: z.string().min(1, 'Payment method is required'),
  same_as_billing: z.boolean().default(true),
});

type CheckoutFormData = z.infer<typeof checkoutSchema>;

export default function Checkout() {
  const { items, total, clearCart } = useCart();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<CheckoutFormData>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      billing: {
        first_name: '',
        last_name: '',
        email: '',
        phone: '',
        address_1: '',
        address_2: '',
        city: '',
        postcode: '',
        country: 'US',
        state: '',
      },
      shipping_method: '',
      payment_method: '',
      same_as_billing: true,
    },
  });

  // Fetch shipping methods
  const {
    data: shippingMethods,
    isLoading: isLoadingShipping,
  } = useQuery({
    queryKey: ['/api/shipping-methods'],
    queryFn: () => wooCommerce.getShippingMethods(),
    staleTime: 10 * 60 * 1000,
  });

  // Fetch payment gateways
  const {
    data: paymentGateways,
    isLoading: isLoadingPayment,
  } = useQuery({
    queryKey: ['/api/payment-gateways'],
    queryFn: () => wooCommerce.getPaymentGateways(),
    staleTime: 10 * 60 * 1000,
  });

  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (orderData: CheckoutFormData) => {
      const order = {
        payment_method: orderData.payment_method,
        payment_method_title: paymentGateways?.find(pg => pg.id === orderData.payment_method)?.title || 'Payment',
        set_paid: false,
        billing: orderData.billing,
        shipping: orderData.same_as_billing ? orderData.billing : orderData.billing, // Simplified for demo
        line_items: items.map(item => ({
          id: 0, // Will be set by WooCommerce
          product_id: item.product.id,
          name: item.product.name,
          quantity: item.quantity,
          total: (parseFloat(item.product.price) * item.quantity).toString(),
        })),
        shipping_lines: shippingMethods?.filter(sm => sm.instance_id === orderData.shipping_method).map(sm => ({
          method_id: sm.method_id,
          method_title: sm.title,
          total: sm.cost,
        })) || [],
      };

      return await wooCommerce.createOrder(order);
    },
    onSuccess: (order) => {
      toast({
        title: "Order Placed Successfully!",
        description: `Your order #${order.id} has been created.`,
      });
      
      // Clear cart and redirect
      clearCart();
      setLocation(`/order-confirmation/${order.id}`);
    },
    onError: (error) => {
      console.error('Order creation error:', error);
      toast({
        title: "Order Failed",
        description: error?.message || "Failed to create order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: CheckoutFormData) => {
    setIsSubmitting(true);
    try {
      await createOrderMutation.mutateAsync(data);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBack = () => {
    setLocation('/cart');
  };

  if (items.length === 0) {
    setLocation('/cart');
    return null;
  }

  return (
    <div className="flex-1 pb-24">
      <div className="px-4 py-6">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBack}
            className="mr-3"
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">
            Checkout
          </h1>
        </div>
        
        {/* Order Summary */}
        <div className="bg-accent rounded-lg p-4 mb-6">
          <h3 className="font-semibold mb-3">Order Summary</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>{items.length} items</span>
              <span data-testid="text-items-total">${total.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span data-testid="text-shipping-cost">TBD</span>
            </div>
            <div className="flex justify-between">
              <span>Tax</span>
              <span data-testid="text-tax-cost">TBD</span>
            </div>
            <Separator />
            <div className="flex justify-between font-semibold">
              <span>Total</span>
              <span data-testid="text-order-total">${total.toFixed(2)}+</span>
            </div>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Billing Information */}
            <div>
              <h3 className="font-semibold mb-4">Billing Information</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="billing.first_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>First Name</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-first-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="billing.last_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Name</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-last-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="billing.email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} data-testid="input-email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="billing.phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input type="tel" {...field} data-testid="input-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="billing.address_1"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Street Address</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-address" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="billing.city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-city" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="billing.postcode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ZIP Code</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-zip" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </div>

            {/* Shipping Method */}
            <div>
              <h3 className="font-semibold mb-4">Shipping Method</h3>
              {isLoadingShipping ? (
                <div className="space-y-3">
                  {Array.from({ length: 2 }).map((_, i) => (
                    <div key={i} className="p-3 border border-border rounded-lg">
                      <Skeleton className="h-4 w-32 mb-1" />
                      <Skeleton className="h-3 w-48" />
                    </div>
                  ))}
                </div>
              ) : (
                <FormField
                  control={form.control}
                  name="shipping_method"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <RadioGroup
                          value={field.value}
                          onValueChange={field.onChange}
                          data-testid="radio-shipping-methods"
                        >
                          {shippingMethods?.length ? (
                            shippingMethods.map((method) => (
                              <div key={method.instance_id} className="flex items-center space-x-3 p-3 border border-border rounded-lg">
                                <RadioGroupItem value={method.instance_id} />
                                <div className="flex-1">
                                  <div className="flex justify-between">
                                    <Label className="font-medium">{method.title}</Label>
                                    <span>${parseFloat(method.cost).toFixed(2)}</span>
                                  </div>
                                  <p className="text-sm text-muted-foreground">{method.method_title}</p>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="p-3 border border-border rounded-lg">
                              <Label className="font-medium">Standard Shipping</Label>
                              <p className="text-sm text-muted-foreground">5-7 business days</p>
                            </div>
                          )}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>

            {/* Payment Method */}
            <div>
              <h3 className="font-semibold mb-4">Payment Method</h3>
              {isLoadingPayment ? (
                <div className="space-y-3">
                  {Array.from({ length: 2 }).map((_, i) => (
                    <div key={i} className="p-3 border border-border rounded-lg">
                      <Skeleton className="h-4 w-32" />
                    </div>
                  ))}
                </div>
              ) : (
                <FormField
                  control={form.control}
                  name="payment_method"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <RadioGroup
                          value={field.value}
                          onValueChange={field.onChange}
                          data-testid="radio-payment-methods"
                        >
                          {paymentGateways?.length ? (
                            paymentGateways.map((gateway) => (
                              <div key={gateway.id} className="flex items-center space-x-3 p-3 border border-border rounded-lg">
                                <RadioGroupItem value={gateway.id} />
                                <div className="flex-1">
                                  <Label className="font-medium">{gateway.title}</Label>
                                  {gateway.description && (
                                    <p className="text-sm text-muted-foreground">{gateway.description}</p>
                                  )}
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="p-3 border border-border rounded-lg">
                              <Label className="font-medium">Credit/Debit Card</Label>
                              <p className="text-sm text-muted-foreground">Secure payment processing</p>
                            </div>
                          )}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>

            {/* Place Order Button */}
            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={isSubmitting || createOrderMutation.isPending}
              data-testid="button-place-order"
            >
              {isSubmitting || createOrderMutation.isPending ? 'Placing Order...' : 'Place Order'}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
