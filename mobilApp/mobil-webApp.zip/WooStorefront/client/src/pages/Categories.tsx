import { useQuery } from '@tanstack/react-query';
import { wooCommerce } from '@/lib/woocommerce';
import { Category } from '@/lib/types';
import { PullToRefresh } from '@/components/PullToRefresh';
import { Skeleton } from '@/components/ui/skeleton';
import { ChevronRight } from 'lucide-react';
import { Link } from 'wouter';

export default function Categories() {
  const {
    data: categories,
    isLoading,
    refetch,
    error,
  } = useQuery({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      return await wooCommerce.getCategories({ per_page: 50, parent: 0 });
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const handleRefresh = async () => {
    await refetch();
  };

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <div className="text-destructive mb-4">
            <h2 className="text-xl font-semibold mb-2">Failed to Load Categories</h2>
            <p className="text-sm text-muted-foreground">
              {error?.message || 'Unable to fetch categories from WooCommerce API'}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={handleRefresh} className="flex-1 pb-20">
      <div className="px-4 py-6">
        <h1 className="text-2xl font-bold mb-6" data-testid="text-page-title">
          Shop by Category
        </h1>
        
        <div className="space-y-4">
          {isLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-card rounded-lg border border-border p-4 flex items-center space-x-4">
                <Skeleton className="w-16 h-16 rounded-lg" />
                <div className="flex-1">
                  <Skeleton className="h-5 w-32 mb-2" />
                  <Skeleton className="h-4 w-48 mb-1" />
                  <Skeleton className="h-3 w-20" />
                </div>
                <Skeleton className="w-5 h-5" />
              </div>
            ))
          ) : categories?.length ? (
            categories.map((category: Category) => (
              <Link key={category.id} href={`/categories/${category.id}`}>
                <div 
                  className="bg-card rounded-lg border border-border shadow-sm hover:shadow-md transition-shadow p-4 flex items-center space-x-4"
                  data-testid={`card-category-${category.id}`}
                >
                  <img 
                    src={category.image?.src || '/placeholder-category.svg'}
                    alt={category.name}
                    className="w-16 h-16 object-cover rounded-lg" 
                    loading="lazy"
                    data-testid={`img-category-${category.id}`}
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold" data-testid={`text-category-name-${category.id}`}>
                      {category.name}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-category-description-${category.id}`}>
                      {category.description || 'Explore our collection'}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1" data-testid={`text-category-count-${category.id}`}>
                      {category.count} products
                    </p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </div>
              </Link>
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No categories found</p>
            </div>
          )}
        </div>
      </div>
    </PullToRefresh>
  );
}
