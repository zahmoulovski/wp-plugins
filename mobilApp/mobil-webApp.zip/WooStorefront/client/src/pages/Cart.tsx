import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import { Link, useLocation } from 'wouter';

export default function Cart() {
  const { items, total, itemCount, updateQuantity, removeItem, clearCart } = useCart();
  const [, setLocation] = useLocation();

  const handleQuantityChange = (id: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(id);
    } else {
      updateQuantity(id, newQuantity);
    }
  };

  const handleProceedToCheckout = () => {
    setLocation('/checkout');
  };

  if (items.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-4 pb-24">
        <div className="text-center">
          <ShoppingBag className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
          <h2 className="text-xl font-semibold mb-2">Your cart is empty</h2>
          <p className="text-muted-foreground mb-6">
            Add some products to get started
          </p>
          <Link href="/">
            <Button data-testid="button-continue-shopping">
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 pb-24">
      <div className="px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold" data-testid="text-page-title">
            Shopping Cart
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearCart}
            className="text-destructive"
            data-testid="button-clear-cart"
          >
            Clear All
          </Button>
        </div>
        
        {/* Cart Items */}
        <div className="space-y-4 mb-6">
          {items.map((item) => {
            const price = parseFloat(item.product.sale_price || item.product.regular_price || item.product.price);
            const itemTotal = price * item.quantity;

            return (
              <div 
                key={item.id} 
                className="bg-card rounded-lg border border-border p-4 flex items-center space-x-4"
                data-testid={`cart-item-${item.id}`}
              >
                <Link href={`/product/${item.product.id}`}>
                  <img 
                    src={item.product.images?.[0]?.src || '/placeholder-product.svg'}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded-lg cursor-pointer" 
                    data-testid={`img-cart-item-${item.id}`}
                  />
                </Link>
                
                <div className="flex-1">
                  <Link href={`/product/${item.product.id}`}>
                    <h3 className="font-medium cursor-pointer hover:text-primary" data-testid={`text-cart-item-name-${item.id}`}>
                      {item.product.name}
                    </h3>
                  </Link>
                  <p className="text-sm text-muted-foreground" data-testid={`text-cart-item-price-${item.id}`}>
                    {price.toFixed(2)}  TND chaque
                  </p>
                  
                  {/* Quantity Controls */}
                  <div className="flex items-center space-x-2 mt-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                      className="h-8 w-8"
                      data-testid={`button-decrease-${item.id}`}
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span 
                      className="px-3 py-1 bg-accent rounded text-sm min-w-[2.5rem] text-center"
                      data-testid={`text-quantity-${item.id}`}
                    >
                      {item.quantity}
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                      className="h-8 w-8"
                      data-testid={`button-increase-${item.id}`}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="text-right">
                  <p className="font-semibold" data-testid={`text-cart-item-total-{item.id}`}>                   {itemTotal.toFixed(2)} TND
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeItem(item.id)}
                    className="text-destructive hover:text-destructive mt-2 p-1"
                    data-testid={`button-remove-${item.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Cart Summary */}
        <div className="bg-accent rounded-lg p-4 mb-6">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Items ({itemCount})</span>
              <span data-testid="text-subtotal">{total.toFixed(2)} TND</span>
            </div>
            
            <Separator />
            <div className="flex justify-between font-semibold text-lg">
              <span>Total</span>
              <span data-testid="text-total">{total.toFixed(2)} TND</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            className="w-full"
            onClick={handleProceedToCheckout}
            size="lg"
            data-testid="button-checkout"
          >
            Passer la commande 
          </Button>
          
          <Link href="/">
            <Button
              variant="outline"
              className="w-full"
              size="lg"
              data-testid="button-continue-shopping"
            >
              Poursuivre les achats
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
