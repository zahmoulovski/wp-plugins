import { useState, useCallback, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { wooCommerce } from '@/lib/woocommerce';
import { Product } from '@/lib/types';
import { ProductCard } from '@/components/ProductCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Search as SearchIcon } from 'lucide-react';

export default function Search() {
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('klarrion-recent-searches');
    if (saved) {
      try {
        setRecentSearches(JSON.parse(saved));
      } catch (error) {
        console.error('Error loading recent searches:', error);
      }
    }
  }, []);

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  const {
    data: searchResults,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['/api/products', 'search', debouncedSearchTerm],
    queryFn: async () => {
      if (!debouncedSearchTerm.trim()) return { products: [], total: 0, totalPages: 0 };
      return await wooCommerce.getProducts({
        search: debouncedSearchTerm,
        per_page: 20,
      });
    },
    enabled: debouncedSearchTerm.trim().length > 0,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const handleSearch = useCallback((term: string) => {
    setSearchTerm(term);
    if (term.trim()) {
      // Add to recent searches
      const newRecentSearches = [term, ...recentSearches.filter(s => s !== term)].slice(0, 5);
      setRecentSearches(newRecentSearches);
      localStorage.setItem('klarrion-recent-searches', JSON.stringify(newRecentSearches));
    }
  }, [recentSearches]);

  const handleRecentSearch = (term: string) => {
    setSearchTerm(term);
    setDebouncedSearchTerm(term);
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem('klarrion-recent-searches');
  };

  return (
    <div className="flex-1 pb-20">
      <div className="px-4 py-6">
        {/* Search Input */}
        <div className="relative mb-6">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search for products..."
            value={searchTerm}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-10"
            data-testid="input-search"
          />
        </div>

        {/* Recent Searches */}
        {!debouncedSearchTerm && recentSearches.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">Recent Searches</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearRecentSearches}
                data-testid="button-clear-recent"
              >
                Clear
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {recentSearches.map((term, index) => (
                <Button
                  key={index}
                  variant="secondary"
                  size="sm"
                  onClick={() => handleRecentSearch(term)}
                  className="rounded-full text-sm"
                  data-testid={`button-recent-search-${index}`}
                >
                  {term}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Search Results */}
        <div data-testid="search-results">
          {!debouncedSearchTerm ? (
            <div className="text-center text-muted-foreground py-8">
              <SearchIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Start typing to search for products</p>
            </div>
          ) : isLoading ? (
            <div>
              <h3 className="font-semibold mb-4">Searching...</h3>
              <div className="grid grid-cols-2 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-card rounded-lg border border-border shadow-sm">
                    <Skeleton className="w-full h-32 rounded-t-lg" />
                    <div className="p-3">
                      <Skeleton className="h-4 w-full mb-1" />
                      <Skeleton className="h-3 w-3/4 mb-2" />
                      <div className="flex items-center justify-between">
                        <Skeleton className="h-4 w-16" />
                        <Skeleton className="h-8 w-16" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : error ? (
            <div className="text-center py-8">
              <p className="text-destructive mb-2">Search Error</p>
              <p className="text-sm text-muted-foreground">
                {error?.message || 'Failed to search products'}
              </p>
            </div>
          ) : searchResults?.products?.length ? (
            <div>
              <h3 className="font-semibold mb-4" data-testid="text-results-count">
                Found {searchResults.total} results for "{debouncedSearchTerm}"
              </h3>
              <div className="grid grid-cols-2 gap-4">
                {searchResults.products.map((product: Product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-2">No products found</p>
              <p className="text-sm text-muted-foreground">
                Try searching with different keywords
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
