import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Settings, Bell, MapPin, Shield, User, Package, ChevronRight } from 'lucide-react';

export default function Profile() {
  // Mock user data - in real app, this would come from WooCommerce Customer API
  const [user] = useState({
    id: 1,
    first_name: 'John',
    last_name: 'Doe',
    email: 'john.doe@example.com',
    username: 'johndoe',
  });

  // Mock order history - in real app, this would be fetched from WooCommerce Orders API
  const mockOrders = [
    {
      id: 12345,
      status: 'completed',
      date_created: '2024-03-15T10:30:00Z',
      total: '799.97',
      line_items: [
        { name: 'Wireless Headphones', quantity: 1 },
        { name: 'Smart Watch', quantity: 1 }
      ]
    },
    {
      id: 12344,
      status: 'processing',
      date_created: '2024-03-10T14:20:00Z',
      total: '199.99',
      line_items: [
        { name: 'Bluetooth Speaker', quantity: 1 }
      ]
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="flex-1 pb-24">
      <div className="px-4 py-6">
        <h1 className="text-2xl font-bold mb-6" data-testid="text-page-title">
          Profile
        </h1>
        
        {/* Profile Information */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-semibold text-xl" data-testid="text-user-avatar">
                  {user.first_name.charAt(0)}{user.last_name.charAt(0)}
                </span>
              </div>
              <div>
                <h3 className="font-semibold" data-testid="text-user-name">
                  {user.first_name} {user.last_name}
                </h3>
                <p className="text-muted-foreground" data-testid="text-user-email">
                  {user.email}
                </p>
                <p className="text-sm text-muted-foreground" data-testid="text-username">
                  @{user.username}
                </p>
              </div>
            </div>
            
            <Button 
              variant="outline" 
              className="w-full"
              data-testid="button-edit-profile"
            >
              <User className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
          </CardContent>
        </Card>

        {/* Order History */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Recent Orders</span>
              <Button variant="ghost" size="sm" data-testid="button-view-all-orders">
                View All
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockOrders.map((order) => (
                <div key={order.id} className="border border-border rounded-lg p-4" data-testid={`card-order-${order.id}`}>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-medium" data-testid={`text-order-id-${order.id}`}>
                        Order #{order.id}
                      </p>
                      <p className="text-sm text-muted-foreground" data-testid={`text-order-date-${order.id}`}>
                        {formatDate(order.date_created)}
                      </p>
                    </div>
                    <span 
                      className={`px-2 py-1 text-xs rounded-full ${getStatusColor(order.status)}`}
                      data-testid={`status-order-${order.id}`}
                    >
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </div>
                  <p className="text-sm" data-testid={`text-order-summary-${order.id}`}>
                    {order.line_items.length} items • ${order.total}
                  </p>
                  <div className="text-xs text-muted-foreground mt-1">
                    {order.line_items.map((item, index) => (
                      <span key={index}>
                        {item.name} (×{item.quantity})
                        {index < order.line_items.length - 1 && ', '}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Settings Menu */}
        <Card>
          <CardHeader>
            <CardTitle>Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              <Button
                variant="ghost"
                className="w-full justify-between h-auto p-3"
                data-testid="button-notifications"
              >
                <div className="flex items-center">
                  <Bell className="w-5 h-5 mr-3 text-muted-foreground" />
                  <span>Notifications</span>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </Button>
              
              <Button
                variant="ghost"
                className="w-full justify-between h-auto p-3"
                data-testid="button-address-book"
              >
                <div className="flex items-center">
                  <MapPin className="w-5 h-5 mr-3 text-muted-foreground" />
                  <span>Address Book</span>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </Button>
              
              <Button
                variant="ghost"
                className="w-full justify-between h-auto p-3"
                data-testid="button-privacy"
              >
                <div className="flex items-center">
                  <Shield className="w-5 h-5 mr-3 text-muted-foreground" />
                  <span>Privacy Settings</span>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </Button>
              
              <Separator className="my-2" />
              
              <Button
                variant="ghost"
                className="w-full justify-between h-auto p-3"
                data-testid="button-account-settings"
              >
                <div className="flex items-center">
                  <Settings className="w-5 h-5 mr-3 text-muted-foreground" />
                  <span>Account Settings</span>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </Button>
              
              <Button
                variant="ghost"
                className="w-full justify-between h-auto p-3"
                data-testid="button-order-history"
              >
                <div className="flex items-center">
                  <Package className="w-5 h-5 mr-3 text-muted-foreground" />
                  <span>Order History</span>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Account Actions */}
        <div className="mt-6 space-y-3">
          <Button variant="outline" className="w-full" data-testid="button-help">
            Help & Support
          </Button>
          <Button variant="outline" className="w-full text-destructive" data-testid="button-logout">
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  );
}
