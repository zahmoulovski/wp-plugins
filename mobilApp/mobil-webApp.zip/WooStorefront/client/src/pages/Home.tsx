import { useQuery } from '@tanstack/react-query';
import { useState, useCallback } from 'react';
import { wooCommerce } from '@/lib/woocommerce';
import { Product, Category } from '@/lib/types';
import { ProductCard } from '@/components/ProductCard';
import { PullToRefresh } from '@/components/PullToRefresh';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Search, RefreshCw } from 'lucide-react';
import { Link, useLocation } from 'wouter';

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [refreshKey, setRefreshKey] = useState(0);

  const {
    data: productsData,
    isLoading: isLoadingProducts,
    refetch: refetchProducts,
    error: productsError,
  } = useQuery({
    queryKey: ['/api/products', 'home', refreshKey],
    queryFn: async () => {
      const result = await wooCommerce.getProducts({ per_page: 12, page: 1 });
      return {
        ...result,
        products: shuffleArray(result.products),
      };
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const {
    data: categories,
    isLoading: isLoadingCategories,
    error: categoriesError,
  } = useQuery({
    queryKey: ['/api/categories', 'featured'],
    queryFn: async () => {
      const result = await wooCommerce.getCategories({ per_page: 4, parent: 0 });
      return result;
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const handleRefresh = useCallback(async () => {
    setRefreshKey(prev => prev + 1);
    await refetchProducts();
  }, [refetchProducts]);

  const handleSearchFocus = () => {
    setLocation('/search');
  };

  const handleShuffleProducts = () => {
    setRefreshKey(prev => prev + 1);
  };

  if (productsError || categoriesError) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <div className="text-destructive mb-4">
            <h2 className="text-xl font-semibold mb-2">Connection Error</h2>
            <p className="text-sm text-muted-foreground">
              {productsError?.message || categoriesError?.message || 'Failed to load content'}
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Please check your WooCommerce API configuration
            </p>
          </div>
          <Button onClick={handleRefresh} variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={handleRefresh} className="flex-1">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-secondary text-primary-foreground">
        <div className="px-4 py-8">
          <h1 className="text-2xl font-bold mb-2">Welcome to Klarrion</h1>
          <p className="text-primary-foreground/80 text-sm mb-4">
            Discover amazing products at great prices
          </p>
          
          {/* Quick search bar */}
          <div className="relative">
            <button
              onClick={handleSearchFocus}
              className="w-full text-left pl-10 pr-4 py-3 rounded-lg bg-white/20 backdrop-blur text-primary-foreground placeholder-primary-foreground/70 border border-white/30 focus:border-white/50 focus:outline-none"
              data-testid="button-search-focus"
            >
              <span className="text-primary-foreground/70">Search products...</span>
            </button>
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-primary-foreground/70" />
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Shop Categories</h2>
          <Link href="/categories">
            <Button variant="ghost" size="sm" data-testid="link-view-all-categories">
              View All
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          {isLoadingCategories ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="bg-card rounded-lg border border-border p-4 text-center">
                <Skeleton className="w-full h-20 rounded-md mb-2" />
                <Skeleton className="h-4 w-16 mx-auto mb-1" />
                <Skeleton className="h-3 w-12 mx-auto" />
              </div>
            ))
          ) : (
            categories?.slice(0, 4).map((category: Category) => (
              <Link key={category.id} href={`/categories/${category.id}`}>
                <div className="bg-card rounded-lg border border-border p-4 text-center shadow-sm hover:shadow-md transition-shadow" data-testid={`card-category-${category.id}`}>
                  <img
                    src={category.image?.src || '/placeholder-category.svg'}
                    alt={category.name}
                    className="w-full h-20 object-cover rounded-md mb-2"
                    loading="lazy"
                  />
                  <h3 className="font-medium text-sm" data-testid={`text-category-name-${category.id}`}>
                    {category.name}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1" data-testid={`text-category-count-${category.id}`}>
                    {category.count} items
                  </p>
                </div>
              </Link>
            ))
          )}
        </div>
      </section>

      {/* Randomized Products Grid */}
      <section className="px-4 py-6 pb-24">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Featured Products</h2>
          <Button
            variant="ghost" 
            size="sm"
            onClick={handleShuffleProducts}
            disabled={isLoadingProducts}
            data-testid="button-shuffle-products"
          >
            <RefreshCw className={`w-4 h-4 mr-1 ${isLoadingProducts ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {isLoadingProducts ? (
            Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-card rounded-lg border border-border shadow-sm">
                <Skeleton className="w-full h-32 rounded-t-lg" />
                <div className="p-3">
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-3 w-3/4 mb-2" />
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-8 w-16" />
                  </div>
                </div>
              </div>
            ))
          ) : productsData?.products?.length ? (
            productsData.products.map((product: Product) => (
              <ProductCard key={product.id} product={product} />
            ))
          ) : (
            <div className="col-span-2 text-center py-8">
              <p className="text-muted-foreground">No products found</p>
            </div>
          )}
        </div>

        {/* Load More Button */}
        {productsData?.products?.length && (
          <div className="text-center mt-6">
            <Button
              variant="outline"
              onClick={() => {/* TODO: Implement load more */}}
              data-testid="button-load-more"
            >
              Load More Products
            </Button>
          </div>
        )}
      </section>
    </PullToRefresh>
  );
}
