import { useQuery } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { useState } from 'react';
import { wooCommerce } from '@/lib/woocommerce';
import { Product as ProductType } from '@/lib/types';
import { ProductCard } from '@/components/ProductCard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useCart } from '@/contexts/CartContext';
import { ArrowLeft, Heart, Minus, Plus } from 'lucide-react';
import DOMPurify from 'dompurify';

export default function Product() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  const productId = parseInt(params.id as string);

  const {
    data: product,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['/api/products', productId],
    queryFn: async () => {
      return await wooCommerce.getProduct(productId);
    },
    enabled: !isNaN(productId),
    staleTime: 5 * 60 * 1000,
  });

  const {
    data: relatedProducts,
    isLoading: isLoadingRelated,
  } = useQuery({
    queryKey: ['/api/products', 'related', product?.categories?.[0]?.id],
    queryFn: async () => {
      if (!product?.categories?.[0]?.id) return { products: [], total: 0, totalPages: 0 };
      
      const result = await wooCommerce.getProducts({
        category: product.categories[0].id,
        per_page: 4,
        exclude: [productId],
      });
      return result;
    },
    enabled: !!product?.categories?.[0]?.id,
    staleTime: 10 * 60 * 1000,
  });

  const handleBack = () => {
    window.history.back();
  };

  const handleAddToCart = () => {
    if (product) {
      addItem(product, quantity);
      // TODO: Show toast notification
    }
  };

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1) {
      setQuantity(newQuantity);
    }
  };

  const handleToggleFavorite = () => {
    // TODO: Implement favorites functionality
  };

  if (isNaN(productId)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-destructive">Invalid product ID</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-destructive mb-2">Product Not Found</p>
          <p className="text-sm text-muted-foreground mb-4">
            {error?.message || 'Unable to load product details'}
          </p>
          <Button onClick={handleBack} variant="outline">
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex-1 pb-20">
        {/* Image Gallery Skeleton */}
        <div className="relative">
          <Skeleton className="w-full h-64" />
          <div className="absolute top-4 left-4">
            <Skeleton className="w-10 h-10 rounded-full" />
          </div>
          <div className="absolute top-4 right-4">
            <Skeleton className="w-10 h-10 rounded-full" />
          </div>
        </div>

        {/* Product Details Skeleton */}
        <div className="px-4 py-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-32" />
            </div>
            <Skeleton className="h-8 w-20" />
          </div>

          <div className="bg-accent rounded-lg p-4 mb-6">
            <div className="grid grid-cols-2 gap-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i}>
                  <Skeleton className="h-4 w-16 mb-1" />
                  <Skeleton className="h-4 w-20" />
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-4 mb-6">
            <Skeleton className="w-24 h-10" />
            <Skeleton className="flex-1 h-12" />
          </div>

          <div className="mb-6">
            <Skeleton className="h-5 w-24 mb-3" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-5/6" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Product not found</p>
      </div>
    );
  }

  const currentImage = product.images?.[selectedImageIndex] || product.images?.[0];
  const price = product.sale_price || product.regular_price || product.price;
  const isOnSale = product.sale_price && product.regular_price && product.sale_price !== product.regular_price;

  return (
    <div className="flex-1 pb-20">
      {/* Product Image Gallery */}
      <div className="relative">
        <img 
          src={currentImage?.src || '/placeholder-product.svg'}
          alt={product.name}
          className="w-full h-64 object-cover" 
          data-testid="img-product-main"
        />
        
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="absolute top-4 left-4 bg-white/80 rounded-full shadow-sm hover:bg-white"
          data-testid="button-back"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        
        <Button
          variant="ghost"
          size="icon"
          onClick={handleToggleFavorite}
          className="absolute top-4 right-4 bg-white/80 rounded-full shadow-sm hover:bg-white"
          data-testid="button-favorite"
        >
          <Heart className="w-5 h-5" />
        </Button>

        {/* Image thumbnails */}
        {product.images && product.images.length > 1 && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
            <div className="flex space-x-2">
              {product.images.slice(0, 5).map((_, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImageIndex(index)}
                  className={`w-2 h-2 rounded-full ${
                    index === selectedImageIndex ? 'bg-white' : 'bg-white/50'
                  }`}
                  data-testid={`button-image-${index}`}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Product Details */}
      <div className="px-4 py-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h1 className="text-xl font-bold mb-2" data-testid="text-product-name">
              {product.name}
            </h1>
            <p className="text-sm text-muted-foreground" data-testid="text-product-sku">
              SKU: {product.sku || 'N/A'}
            </p>
          </div>
          <div className="text-right">
            <div className="flex items-center space-x-2">
              {isOnSale && (
                <span className="text-sm text-muted-foreground line-through" data-testid="text-regular-price">
                  {parseFloat(product.regular_price).toFixed(2)} TND
                </span>
              )}
              <span className="text-2xl font-bold text-primary" data-testid="text-product-price">
                {parseFloat(price).toFixed(2)} TND
              </span>
            </div>
            {isOnSale && (
              <span className="text-xs bg-destructive text-destructive-foreground px-2 py-1 rounded-full">
                Promo
              </span>
            )}
          </div>
        </div>

        {/* Product Attributes */}
        <div className="bg-accent rounded-lg p-4 mb-6">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Stock:</span>
              <span className={`ml-2 font-medium ${
                product.stock_status === 'instock' ? 'text-green-600' :
                product.stock_status === 'outofstock' ? 'text-red-600' : 'text-yellow-600'
              }`} data-testid="text-stock-status">
                {product.stock_status === 'instock' ? 'In Stock' :
                 product.stock_status === 'outofstock' ? 'Out of Stock' : 'On Backorder'}
              </span>
            </div>
            {product.categories?.[0] && (
              <div>
                <span className="text-muted-foreground">Category:</span>
                <span className="ml-2 font-medium" data-testid="text-product-category">
                  {product.categories[0].name}
                </span>
              </div>
            )}
            {product.stock_quantity !== null && (
              <div>
                <span className="text-muted-foreground">Available:</span>
                <span className="ml-2 font-medium" data-testid="text-stock-quantity">
                  {product.stock_quantity}
                </span>
              </div>
            )}
            {product.attributes?.length > 0 && (
              <div>
                <span className="text-muted-foreground">{product.attributes[0].name}:</span>
                <span className="ml-2 font-medium">
                  {product.attributes[0].options.join(', ')}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Quantity and Add to Cart */}
        <div className="flex items-center space-x-4 mb-6">
          <div className="flex items-center border border-border rounded-lg">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleQuantityChange(quantity - 1)}
              disabled={quantity <= 1}
              data-testid="button-decrease-quantity"
            >
              <Minus className="w-4 h-4" />
            </Button>
            <span className="px-4 py-2 text-center min-w-[3rem]" data-testid="text-quantity">
              {quantity}
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleQuantityChange(quantity + 1)}
              data-testid="button-increase-quantity"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <Button
            className="flex-1"
            onClick={handleAddToCart}
            disabled={product.stock_status === 'outofstock'}
            data-testid="button-add-to-cart"
          >
            Add to Cart
          </Button>
        </div>

        {/* Product Description */}
        <div className="mb-6">
          <h3 className="font-semibold mb-3">Description</h3>
          <div 
            className="prose prose-sm max-w-none text-muted-foreground"
            dangerouslySetInnerHTML={{ 
              __html: DOMPurify.sanitize(product.description || product.short_description || '<p>No description available</p>')
            }}
            data-testid="text-product-description"
          />
        </div>

        {/* Related Products */}
        {relatedProducts?.products && relatedProducts.products.length > 0 && (
          <div>
            <h3 className="font-semibold mb-4">Related Products</h3>
            <div className="grid grid-cols-2 gap-4">
              {isLoadingRelated ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="bg-card rounded-lg border border-border shadow-sm">
                    <Skeleton className="w-full h-24 rounded-t-lg" />
                    <div className="p-2">
                      <Skeleton className="h-4 w-3/4 mb-1" />
                      <Skeleton className="h-4 w-16" />
                    </div>
                  </div>
                ))
              ) : (
                relatedProducts?.products?.map((relatedProduct: ProductType) => (
                  <div key={relatedProduct.id} className="bg-card rounded-lg border border-border shadow-sm">
                    <img 
                      src={relatedProduct.images?.[0]?.src || '/placeholder-product.svg'}
                      alt={relatedProduct.name}
                      className="w-full h-24 object-cover rounded-t-lg" 
                      loading="lazy"
                    />
                    <div className="p-2">
                      <h4 className="font-medium text-sm mb-1 line-clamp-1">
                        {relatedProduct.name}
                      </h4>
                      <span className="text-primary font-semibold text-sm">
                        {parseFloat(relatedProduct.sale_price || relatedProduct.regular_price || relatedProduct.price).toFixed(2)} TND
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
