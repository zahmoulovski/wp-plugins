export interface Product {
  id: number;
  name: string;
  slug: string;
  description: string;
  short_description: string;
  sku: string;
  price: string;
  regular_price: string;
  sale_price: string;
  images: {
    id: number;
    src: string;
    alt: string;
  }[];
  categories: {
    id: number;
    name: string;
    slug: string;
  }[];
  tags: {
    id: number;
    name: string;
    slug: string;
  }[];
  attributes: {
    id: number;
    name: string;
    options: string[];
  }[];
  stock_status: 'instock' | 'outofstock' | 'onbackorder';
  stock_quantity: number | null;
  related_ids: number[];
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  image: {
    id: number;
    src: string;
    alt: string;
  } | null;
  count: number;
  parent: number;
}

export interface CartItem {
  id: number;
  product: Product;
  quantity: number;
  variation_id?: number;
  variation?: { [key: string]: string };
}

export interface ShippingMethod {
  instance_id: string;
  title: string;
  cost: string;
  method_id: string;
  method_title: string;
}

export interface PaymentGateway {
  id: string;
  title: string;
  description: string;
  enabled: boolean;
  method_title: string;
  method_description: string;
}

export interface Order {
  id: number;
  status: string;
  total: string;
  date_created: string;
  line_items: {
    id: number;
    name: string;
    quantity: number;
    total: string;
    product_id: number;
  }[];
  shipping: {
    first_name: string;
    last_name: string;
    address_1: string;
    address_2: string;
    city: string;
    postcode: string;
    country: string;
    state: string;
  };
  billing: {
    first_name: string;
    last_name: string;
    address_1: string;
    address_2: string;
    city: string;
    postcode: string;
    country: string;
    state: string;
    email: string;
    phone: string;
  };
}

export interface Customer {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  username: string;
  shipping: {
    first_name: string;
    last_name: string;
    address_1: string;
    address_2: string;
    city: string;
    postcode: string;
    country: string;
    state: string;
  };
  billing: {
    first_name: string;
    last_name: string;
    address_1: string;
    address_2: string;
    city: string;
    postcode: string;
    country: string;
    state: string;
    email: string;
    phone: string;
  };
}
