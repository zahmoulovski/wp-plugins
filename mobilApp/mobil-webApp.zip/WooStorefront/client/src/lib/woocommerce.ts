import axios from 'axios';
import { Product, Category, ShippingMethod, PaymentGateway, Order, Customer } from './types';

const API_BASE = import.meta.env.VITE_WC_API_BASE || 'https://klarrion.com/wp-json/wc/v3';
const CONSUMER_KEY = import.meta.env.VITE_WC_CONSUMER_KEY || '';
const CONSUMER_SECRET = import.meta.env.VITE_WC_CONSUMER_SECRET || '';

if (!CONSUMER_KEY || !CONSUMER_SECRET) {
  console.warn('WooCommerce API credentials not found. Please set VITE_WC_CONSUMER_KEY and VITE_WC_CONSUMER_SECRET environment variables.');
}

const wooCommerceApi = axios.create({
  baseURL: API_BASE,
  auth: {
    username: CONSUMER_KEY,
    password: CONSUMER_SECRET,
  },
  timeout: 10000,
});

// Add request interceptor for debugging
wooCommerceApi.interceptors.request.use(
  (config) => {
    console.log(`WooCommerce API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
wooCommerceApi.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    console.error('WooCommerce API Error:', error.response?.data || error.message);
    throw new Error(
      error.response?.data?.message || 
      'Failed to connect to WooCommerce API. Please check your configuration.'
    );
  }
);

export const wooCommerce = {
  // Products
  async getProducts(params: {
    page?: number;
    per_page?: number;
    search?: string;
    category?: number;
    orderby?: string;
    order?: 'asc' | 'desc';
    exclude?: number[];
  } = {}): Promise<{ products: Product[]; totalPages: number; total: number }> {
    try {
      const response = await wooCommerceApi.get('/products', { params });
      return {
        products: response.data,
        totalPages: parseInt(response.headers['x-wp-totalpages'] || '1'),
        total: parseInt(response.headers['x-wp-total'] || '0'),
      };
    } catch (error) {
      console.error('Error fetching products:', error);
      throw error;
    }
  },

  async getProduct(id: number): Promise<Product> {
    try {
      const response = await wooCommerceApi.get(`/products/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching product:', error);
      throw error;
    }
  },

  // Categories
  async getCategories(params: {
    page?: number;
    per_page?: number;
    parent?: number;
  } = {}): Promise<Category[]> {
    try {
      const response = await wooCommerceApi.get('/products/categories', { params });
      return response.data;
    } catch (error) {
      console.error('Error fetching categories:', error);
      throw error;
    }
  },

  async getCategory(id: number): Promise<Category> {
    try {
      const response = await wooCommerceApi.get(`/products/categories/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching category:', error);
      throw error;
    }
  },

  // Shipping
  async getShippingMethods(): Promise<ShippingMethod[]> {
    try {
      const response = await wooCommerceApi.get('/shipping/zones');
      const zones = response.data;
      const allMethods: ShippingMethod[] = [];
      
      for (const zone of zones) {
        const methodsResponse = await wooCommerceApi.get(`/shipping/zones/${zone.id}/methods`);
        allMethods.push(...methodsResponse.data);
      }
      
      return allMethods;
    } catch (error) {
      console.error('Error fetching shipping methods:', error);
      return [];
    }
  },

  // Payment
  async getPaymentGateways(): Promise<PaymentGateway[]> {
    try {
      const response = await wooCommerceApi.get('/payment_gateways');
      return response.data.filter((gateway: PaymentGateway) => gateway.enabled);
    } catch (error) {
      console.error('Error fetching payment gateways:', error);
      return [];
    }
  },

  // Orders
  async createOrder(orderData: Partial<Order>): Promise<Order> {
    try {
      const response = await wooCommerceApi.post('/orders', orderData);
      return response.data;
    } catch (error) {
      console.error('Error creating order:', error);
      throw error;
    }
  },

  // Customers
  async getCustomer(id: number): Promise<Customer> {
    try {
      const response = await wooCommerceApi.get(`/customers/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching customer:', error);
      throw error;
    }
  },

  async updateCustomer(id: number, customerData: Partial<Customer>): Promise<Customer> {
    try {
      const response = await wooCommerceApi.put(`/customers/${id}`, customerData);
      return response.data;
    } catch (error) {
      console.error('Error updating customer:', error);
      throw error;
    }
  },
};
