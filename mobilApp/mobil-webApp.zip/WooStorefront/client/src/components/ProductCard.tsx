import { ShoppingCart, Plus } from 'lucide-react';
import { Product } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { Link } from 'wouter';

interface ProductCardProps {
  product: Product;
  onAddToCart?: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const { addItem } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onAddToCart) {
      onAddToCart(product);
    } else {
      addItem(product, 1);
    }
  };

  const imageUrl = product.images?.[0]?.src || '/placeholder-image.svg';
  const price = product.sale_price || product.regular_price || product.price;

  return (
    <Link href={`/product/${product.id}`}>
      <div className="bg-card rounded-lg border border-border shadow-sm hover:shadow-md transition-shadow" data-testid={`card-product-${product.id}`}>
        <div className="relative">
          <img 
            src={imageUrl}
            alt={product.name} 
            className="w-full h-32 object-cover rounded-t-lg" 
            loading="lazy"
            data-testid={`img-product-${product.id}`}
          />
          
        </div>
        <div className="p-3">
          <h3 className="font-medium text-sm mb-1 line-clamp-2" data-testid={`text-name-${product.id}`}>
            {product.name}
          </h3>
          <h3 className="font-medium text-sm mb-1 line-clamp-2" data-testid={`text-name-${product.sku}`}>
            {product.sku}
          </h3>
          
          <div className="flex items-center justify-between">
            <span className="font-semibold text-primary" data-testid={`text-price-${product.id}`}>
              {parseFloat(price).toFixed(2)} TND
            </span>
            <Button
              size="sm"
              onClick={handleAddToCart}
              className="px-3 py-1.5 text-xs font-medium"
              data-testid={`button-add-to-cart-${product.id}`}
            >
              <ShoppingCart className="w-3 h-3 mr-1" />
              Ajouter au panier
            </Button>
          </div>
        </div>
      </div>
    </Link>
  );
}
