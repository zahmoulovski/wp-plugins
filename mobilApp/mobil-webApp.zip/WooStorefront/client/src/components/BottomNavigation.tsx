import { Home, Grid3x3, Search, ShoppingCart, User } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { useCart } from '@/contexts/CartContext';

export function BottomNavigation() {
  const [location] = useLocation();
  const { itemCount } = useCart();

  const navItems = [
    { path: '/', icon: Home, label: 'Home', testId: 'nav-home' },
    { path: '/categories', icon: Grid3x3, label: 'Categories', testId: 'nav-categories' },
    { path: '/search', icon: Search, label: 'Search', testId: 'nav-search' },
    { path: '/cart', icon: ShoppingCart, label: 'Cart', testId: 'nav-cart', badge: itemCount },
    { path: '/profile', icon: User, label: 'Profile', testId: 'nav-profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border shadow-lg z-50">
      <div className="flex items-center justify-around py-2">
        {navItems.map(({ path, icon: Icon, label, testId, badge }) => {
          const isActive = location === path;
          
          return (
            <Link key={path} href={path}>
              <button 
                className={`nav-item flex flex-col items-center py-2 px-3 transition-colors ${
                  isActive 
                    ? 'text-primary' 
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                data-testid={testId}
              >
                <div className="relative">
                  <Icon className="w-6 h-6 mb-1" />
                  {badge && badge > 0 && (
                    <span className="absolute -top-2 -right-2 bg-secondary text-secondary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium cart-badge">
                      {badge}
                    </span>
                  )}
                </div>
                <span className="text-xs font-medium">{label}</span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
