import { Loader2 } from 'lucide-react';
import { usePullToRefresh } from '@/hooks/usePullToRefresh';

interface PullToRefreshProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
  className?: string;
}

export function PullToRefresh({ onRefresh, children, className = "" }: PullToRefreshProps) {
  const { isRefreshing, pullDistance, touchHandlers } = usePullToRefresh({ onRefresh });

  return (
    <div
      className={`overflow-auto ${className}`}
      {...touchHandlers}
      data-testid="pull-to-refresh-container"
    >
      {/* Pull to refresh indicator */}
      <div 
        className={`text-center py-4 transition-all duration-300 ${
          pullDistance > 0 ? 'block' : 'hidden'
        }`}
        style={{ transform: `translateY(${Math.min(pullDistance - 40, 0)}px)` }}
        data-testid="pull-to-refresh-indicator"
      >
        <div className="inline-flex items-center space-x-2 text-muted-foreground">
          <Loader2 className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          <span className="text-sm">
            {isRefreshing ? 'Refreshing...' : 'Pull to refresh'}
          </span>
        </div>
      </div>

      <div 
        className="pull-to-refresh"
        style={{ transform: `translateY(${pullDistance > 0 ? pullDistance : 0}px)` }}
      >
        {children}
      </div>
    </div>
  );
}
