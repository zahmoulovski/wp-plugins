import { useTheme } from '@/contexts/ThemeContext';
import { Sun, Moon, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Header() {
  const { isDarkMode, toggleTheme } = useTheme();

  const logoSrc = isDarkMode
    ? 'https://klarrion.com/wp-content/uploads/2025/09/logo-klarrion-4.svg'
    : 'https://klarrion.com/wp-content/uploads/2025/09/yellow-logo-klarrion-4.svg';

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center space-x-3">
          <img 
            src={logoSrc}
            alt="Klarrion Logo" 
            className="h-8 w-auto" 
            data-testid="brand-logo"
          />
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full"
            data-testid="button-theme-toggle"
          >
            {isDarkMode ? (
              <Sun className="w-5 h-5" />
            ) : (
              <Moon className="w-5 h-5" />
            )}
          </Button>
        </div>
      </div>
    </header>
  );
}
