# Klarrion E-Commerce PWA

A modern, mobile-first React Progressive Web App (PWA) that integrates with WooCommerce REST API to provide a complete e-commerce experience.

## Features

- **Mobile-First Design**: Optimized for mobile devices with responsive layout
- **WooCommerce Integration**: Complete integration with WooCommerce REST API
- **Dark/Light Mode**: Theme switching with brand-appropriate logos
- **Shopping Cart**: Persistent cart using localStorage with context management
- **Pull-to-Refresh**: Native-like mobile refresh functionality
- **Product Search**: Debounced search with recent search history
- **Category Browsing**: Navigate products by category
- **Checkout Flow**: Complete checkout with shipping and payment options
- **Product Gallery**: Swipeable product images
- **Responsive Design**: Works on all screen sizes

## Tech Stack

- **Frontend**: Vite + React 18 + TypeScript
- **Styling**: TailwindCSS + shadcn/ui components
- **Routing**: Wouter
- **State Management**: React Context API + useReducer
- **API Calls**: Axios with React Query
- **Forms**: React Hook Form + Zod validation
- **Icons**: Lucide React
- **HTML Sanitization**: DOMPurify

## Project Structure

